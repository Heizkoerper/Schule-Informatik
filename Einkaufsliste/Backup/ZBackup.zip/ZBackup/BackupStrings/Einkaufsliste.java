/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 30.01.2023
 * @author 
 */

import java.io.*;
import java.util.*;

public class Einkaufsliste {
  
  private List<String> list = new List<>();
  
  
  public void hinzufuegen(String artikel) throws IOException {
    
    list.append(artikel);
    listeSpeichern();
    
  }
  
  
  public void entfernen(String artikel) throws IOException {
    
    if (! pruefen(artikel) ) { System.out.println("Artikel nicht vorhanden"); return; }
    
    list.toFirst();
    while (! list.getContent().equalsIgnoreCase(artikel)) { list.next(); }
    list.remove();
    
    listeSpeichern();
    
  }
  
  
  public boolean pruefen(String artikel) {
    
    if (list.isEmpty()) { return false; }
    else { list.toFirst(); }
    if (! list.hasAccess()) { return false; }
    
    list.toLast(); 
    String last = list.getContent();
    
    list.toFirst();
    
    while (! list.getContent().equalsIgnoreCase(last)) {
      
      if (list.getContent().equalsIgnoreCase(artikel)) { return true; }
      list.next();
      
    }
    
    if (list.getContent().equalsIgnoreCase(artikel)) { return true; }
    
    return false;
    
  }
  
  
  public void ausgeben() {
    
    if (list.isEmpty()) { return; }
    else { list.toFirst(); }
    if (! list.hasAccess()) { return; }
    
    list.toLast(); 
    String last = list.getContent();
    
    list.toFirst();
    
    while (! list.getContent().equalsIgnoreCase(last)) {
      
      System.out.println(list.getContent());
      list.next();
      
    }
    
    System.out.println(list.getContent());
    
  }
  
  
  private void listeSpeichern() throws IOException {
    
    if (list.isEmpty()) { return; }
    else { list.toFirst(); }
    if (! list.hasAccess()) { return; }
    
    try {
      
      new FileOutputStream("liste.txt").close();
      
      FileWriter fw = new FileWriter("liste.txt");
      BufferedWriter bw = new BufferedWriter(fw);
      
      list.toLast(); 
      String last = list.getContent();
      
      list.toFirst();
      
      while (! list.getContent().equalsIgnoreCase(last)) {
        
        bw.write(list.getContent() + "\n");
        list.next();
        
      }
      
      bw.write(list.getContent() + "\n");
      
      bw.close();
      
    }
    
    catch(IOException e) {
      
      System.out.println("Please provide a valid file, or a file at all...");
      System.out.println("Well, anyways, Im gone!");
      
      System.exit(1);
      
    }
  
  }
  
}

